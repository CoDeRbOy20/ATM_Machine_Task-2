package machine;

import people.User;

public class ATM {


    private static final String CORRECT_USER_ID = "user123";
    private static final String CORRECT_PIN = "1234";

    public boolean authenticateUser(String userID, String userPIN) {
        return userID.equals(CORRECT_USER_ID) && userPIN.equals(CORRECT_PIN);
    }

    public void checkBalance(User user) {
        System.out.println("Your current balance is: Rs " + user.getAccountBalance());
    }

    public void withdrawMoney(User user, double amount) {
        if (amount > user.getAccountBalance()) {
            System.out.println("Error: Insufficient funds.");
        } else {
            user.setAccountBalance(user.getAccountBalance() - amount);
            System.out.println("Rs " + amount + " withdrawn successfully.");
        }
    }

    public void depositMoney(User user, double amount) {
        user.setAccountBalance(user.getAccountBalance() + amount);
        System.out.println("Rs " + amount + " deposited successfully.");
    }
    }

